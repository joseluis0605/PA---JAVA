package com.company.excepciones;

public class NoExisteUsuarioException extends Exception{
}
