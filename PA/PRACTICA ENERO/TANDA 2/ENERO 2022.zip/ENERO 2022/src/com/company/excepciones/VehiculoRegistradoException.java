package com.company.excepciones;

public class VehiculoRegistradoException extends Exception{
}
