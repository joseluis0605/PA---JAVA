package com.company.tipoCombustion;

public enum tipoCombustion {
    DIESEL, GASOLINA
}
