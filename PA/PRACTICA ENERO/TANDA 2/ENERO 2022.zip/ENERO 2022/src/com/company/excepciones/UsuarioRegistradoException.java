package com.company.excepciones;

public class UsuarioRegistradoException extends Exception{
}
